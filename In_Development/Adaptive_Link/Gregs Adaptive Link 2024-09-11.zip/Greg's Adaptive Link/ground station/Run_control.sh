#/bin/bash


/home/radxa/./openipc_controlWfb.py -i /home/radxa/rssi_min -o /home/radxa/setLink

exit 1
