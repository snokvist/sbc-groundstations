#!/bin/bash

#killall wfb_tx
./startTX.sh &
sleep 3
./lastline.sh | socat - UDP-DATAGRAM:127.0.0.1:5000,sp=5000



