#/bin/bash

if [ -e /etc/default/wifibroadcast ]; then
	. /etc/default/wifibroadcast
fi

sudo wfb_tx -p 1 -u 5000 -K /etc/gs.key -R 456000 -B20 -M 0 -S 1 -L 1 -G long -k 1 -n 4 -i 7669207 -f data $WFB_NICS