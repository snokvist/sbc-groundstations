#!/bin/bash

while true; do
  # Get the last line of setLink and echo
  last_line=$(tail -n 1 /home/radxa/setLink)
   echo "$last_line"
# | socat - UDP-DATAGRAM:127.0.0.1:5000,sp=5000
  sleep 0.1
done



