#/bin/bash

# usage ./setpower.sh <pwrlvl>

echo Unloading module
modprobe -r 88XXau_wfb &&
echo Loading module with power level $1
modprobe 88XXau_wfb rtw_tx_pwr_idx_override=$1




#if [ -e /etc/default/wifibroadcast ]; then
#. /etc/default/wifibroadcast
#fi
#IFS=' ' read -r -a words <<< "$WFB_NICS"
#
#for nic in "${words[@]}"; do
#    echo "Setting power $1 for $nic"
#    iw $nic set txpower fixed $1
#done